﻿using Azure.Storage.Blobs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    class Program
    {
        private static object configuration;

        static void Main(string[] args)
        {
            string cs = System.Configuration.ConfigurationSettings.AppSettings.Get("ConnectionString");
            // Get a reference to a container
            BlobContainerClient container = new BlobContainerClient(cs, "pdffilecontainer");

            //         await container.CreateAsync();
            container.Create();
            Console.ReadLine();
        }
    }
}
