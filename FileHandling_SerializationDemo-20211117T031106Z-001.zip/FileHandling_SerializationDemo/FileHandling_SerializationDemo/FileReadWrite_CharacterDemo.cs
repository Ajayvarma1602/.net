﻿using System;
using System.IO;

namespace FileHandling_SerializationDemo
{
    class FileReadWrite_CharacterDemo
    {
        static void WriteToFile()
        {

        }

        static void ReadFromFile()
        {
            

        }
        static void Main()
        {
            //  WriteToFile();
           // ReadFromFile();

            Console.WriteLine("Press enter to terminate..");
            Console.ReadLine();
        }
    }
}
