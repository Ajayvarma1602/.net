﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication19.Models
{
    public class ContainerModel
    {
        public string ContainerName { get; set; }
        public string BlobName { get; set; }
        public string BlobContents { get; set; }
    }
}
