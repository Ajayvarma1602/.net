﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnOk_Click(object sender, EventArgs e)
        {
            
            if (CheckBox1.Checked==true)
            {
                lblStatus.Text = "HIB is clicked";
            }
            else if(CheckBox1.Checked==true && CheckBox2.Checked ==true)
            {
                lblStatus.Text = " click only one check box ";
            }
            else if(CheckBox2.Checked==true)
            {
                lblStatus.Text = " passport is clicked ";
            }
            else
            {
                lblStatus.Text = " click any box ";
            }
            foreach(ListItem item in CheckBoxList1.Items)
            {
                if (item.Selected)
                {
                    lblStatus.Text += item.Text;
                }
            }
            foreach(ListItem item in DropDownList1.Items)
            {
                if (item.Selected)
                {
                    lblStatus1.Text = item.Text;
                }
            }
        }
    }
}